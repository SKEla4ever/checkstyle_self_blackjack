package interface_adapter.launch;

public class LaunchState {
    private String placeholder = null;
    public String getPlaceholder() { return placeholder; }
}
