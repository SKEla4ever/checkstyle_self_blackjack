package use_case.playerDoubleDown;

public interface PlayerDoubleDownInputBoundary {
    void execute(PlayerDoubleDownInputData inputData);
}

