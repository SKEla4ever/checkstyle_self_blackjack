package use_case.launch;

public interface LaunchOutputBoundary {

    void switchToLoginView();

    void switchToSignUpView();

}
