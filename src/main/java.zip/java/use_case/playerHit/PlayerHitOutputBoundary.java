package use_case.playerHit;

public interface PlayerHitOutputBoundary {
    void present(PlayerHitOutputData outputData);
}
