package use_case.playerHit;

public interface PlayerHitInputBoundary {
    void execute(PlayerHitInputData inputData);
}
