package use_case.playerHit;

import entity.Card;

public interface PlayerHitUserDataAccessInterface {
    Card drawCard();
}
