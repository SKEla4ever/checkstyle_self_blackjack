package use_case.game_start;

public interface GameStartInputBoundary {
    void execute(GameStartInputData inputData);
}
