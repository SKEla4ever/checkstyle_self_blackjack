package use_case.playerStand;

public interface PlayerStandInputBoundary {
    void execute(PlayerStandInputData inputData);
}
