package use_case.readRule;
import javax.swing.*;

public class ReadRuleOutputData {
    private String text;

    public ReadRuleOutputData(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
