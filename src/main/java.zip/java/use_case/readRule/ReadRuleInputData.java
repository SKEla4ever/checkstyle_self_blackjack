package use_case.readRule;

/**
 * The input or initial data needed for the read rule use case
 */
public class ReadRuleInputData {

    public ReadRuleInputData() {}

}
