package use_case.playerSplit;

public interface PlayerSplitInputBoundary {
    void execute(PlayerSplitInputData inputData);
}
